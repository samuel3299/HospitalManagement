package com.Samuel.Hospital_manager.service;


public interface LoginServiceInterface {

	public default String processLogin(String userMail, String password) {return null;}
}
