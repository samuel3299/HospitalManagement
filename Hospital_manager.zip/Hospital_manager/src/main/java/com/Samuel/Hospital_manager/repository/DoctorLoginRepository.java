package com.Samuel.Hospital_manager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Samuel.Hospital_manager.model.Doctor;

@Repository
public interface DoctorLoginRepository extends JpaRepository<Doctor, Integer> {

}
