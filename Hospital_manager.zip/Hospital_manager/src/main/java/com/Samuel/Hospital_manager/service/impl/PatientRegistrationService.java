package com.Samuel.Hospital_manager.service.impl;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Patients;
import com.Samuel.Hospital_manager.repository.PatientLoginRepository;
import com.Samuel.Hospital_manager.service.PatientRegistrationServiceInterface;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class PatientRegistrationService implements PatientRegistrationServiceInterface {
	
	PatientLoginRepository patientLoginRepository;

	@Override
	public boolean processRegistration(String patientName, String docIncharge, String patientSymptoms, int patientAge,
			String patientMail, String patientPassword, String confirmPassword) {
		// TODO Auto-generated method stub
		Patients p =new Patients();
		if(!patientPassword.equals(confirmPassword)) return false;
		p.setDoc_incharge(docIncharge);
		p.setPatient_age(patientAge);
		p.setPatient_name(patientName);
		p.setPatient_password(patientPassword);
		p.setPatient_symptoms(patientSymptoms);
		patientLoginRepository.save(p);
		return true;
	}

	
}
