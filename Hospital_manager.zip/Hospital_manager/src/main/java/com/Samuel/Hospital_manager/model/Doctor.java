package com.Samuel.Hospital_manager.model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(name = "doctors")
@Data
public class Doctor {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int doc_id;
	
	@Column(unique = true)
	private String doc_name;
	
	@Column(unique = true, name = "doc_mail")
	private String userMail;
	
	@Column(unique = true)
	private String doc_password;
	
	private String doc_dept;
	private double doc_salary;
	
	@CreationTimestamp
	private Date Doc_joined;

	
}
