package com.Samuel.Hospital_manager.service.impl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Department;
import com.Samuel.Hospital_manager.model.Doctor;
import com.Samuel.Hospital_manager.model.Employees;
import com.Samuel.Hospital_manager.model.Medicine;
import com.Samuel.Hospital_manager.model.Patients;
import com.Samuel.Hospital_manager.repository.DepartmentLoginRepository;
import com.Samuel.Hospital_manager.repository.DoctorLoginRepository;
import com.Samuel.Hospital_manager.repository.EmpLoginRepository;
import com.Samuel.Hospital_manager.repository.MedicineLoginRepository;
import com.Samuel.Hospital_manager.repository.PatientLoginRepository;
import com.Samuel.Hospital_manager.service.LoginServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
@AllArgsConstructor
public class LoginService implements LoginServiceInterface {

	DepartmentLoginRepository departmentLoginRepository;
	
	DoctorLoginRepository doctorLoginRepository;
	EmpLoginRepository empLoginRepository;
	MedicineLoginRepository medicineLoginRepository;
	PatientLoginRepository patientLoginRepository;

	@Override
	public String processLogin(String userMail, String password) {
		try {
		if(processDeptLogin(userMail,password)) {
			List<Department> list = departmentLoginRepository.findAll();
			for(Department dept : list) {
				if(dept.getUserMail().equals(userMail) && dept.getDept_name().equals("CEO")) return "deptLogin";
			}
			return "deptPage";
		}
		else if(processMedLogin(userMail,password)) return "medPage";
		else if(processDocLogin(userMail,password)) return "docPage";
		else if(processPatLogin(userMail,password)) return "patientPage";
		else if(processEmpLogin(userMail,password)) return "empPage";
		else {
			log.error("Login Credentials do not match or User not registed");
			return "error";
		}
		}
		catch (Exception e) {
			log.error("Login Credentials do not match or User not registed: "+e);
			return "error";
		}
	}

	private boolean processEmpLogin(String userMail, String password) {
		// TODO Auto-generated method stub
		List<Employees> list = empLoginRepository.findAll();
		for(Employees emp : list) {
			if(emp.getUserMail().equals(userMail) && emp.getEmp_password().equals(password)) return true;
		}
		return false;
	}

	private boolean processPatLogin(String userMail, String password) {
		// TODO Auto-generated method stub
		List<Patients> list = patientLoginRepository.findAll();
		for(Patients pat : list) {
			if(pat.getUserMail().equals(userMail) && pat.getPatient_password().equals(password)) return true;
		}
		return false;
	}

	private boolean processDocLogin(String userMail, String password) {
		// TODO Auto-generated method stub
		List<Doctor> list = doctorLoginRepository.findAll();
		for(Doctor doctor : list) {
			if(doctor.getUserMail().equals(userMail) && doctor.getDoc_password().equals(password)) return true;
		}
		return false;
	}

	private boolean processMedLogin(String userMail, String password) {
		// TODO Auto-generated method stub
		List<Medicine> list = medicineLoginRepository.findAll();
		for(Medicine medicine : list) {
			if(medicine.getUserMail().equals(userMail) && medicine.getMedicalEmp_password().equals(password)) return true;
		}
		return false;
	}

	private boolean processDeptLogin(String userMail, String password) {
		// TODO Auto-generated method stub
		List<Department> list = departmentLoginRepository.findAll();
		for(Department dept : list) {
			if(dept.getUserMail().equals(userMail) && dept.getIncharge_password().equals(password)) return true;
		}
		return false;
	}
}
