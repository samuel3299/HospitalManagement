package com.Samuel.Hospital_manager.service;

public interface DepartmentServiceInterface {

	public boolean processDeptRefForm(String dept_incharge, String dept_name, Integer workers_in_dept, String incharge_mail,
			String dept_password, String confirmPassword);

	
}
