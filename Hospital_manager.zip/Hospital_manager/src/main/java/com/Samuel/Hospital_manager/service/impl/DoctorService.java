package com.Samuel.Hospital_manager.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Doctor;
import com.Samuel.Hospital_manager.repository.DoctorLoginRepository;
import com.Samuel.Hospital_manager.service.DoctorServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@AllArgsConstructor
@Slf4j
public class DoctorService implements DoctorServiceInterface {
 
	DoctorLoginRepository doctorLoginRepository;
	
	@Override
	public boolean ProcessDoctorRegistration(String doc_dept,String doc_name,Double doc_salary,String doc_mail,
			String doc_password,String confirmPassword) {
		if(!doc_password.equals(confirmPassword)) {
			log.info(doc_password+ " "+confirmPassword);
			return false;
		}
		Doctor doc = new Doctor();
		doc.setDoc_dept(doc_dept);
		doc.setDoc_name(doc_name);
		doc.setDoc_password(doc_password);
		doc.setDoc_salary(doc_salary);
		doc.setUserMail(doc_mail);
		doctorLoginRepository.save(doc);
		log.info(doc.toString());
		return true;
	}

	@Override
	public List<Doctor> findallDoctors() {
		// TODO Auto-generated method stub
		
		return doctorLoginRepository.findAll();
	}
}
