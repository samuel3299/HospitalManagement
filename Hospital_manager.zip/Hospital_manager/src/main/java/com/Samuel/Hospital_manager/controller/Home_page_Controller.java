package com.Samuel.Hospital_manager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class Home_page_Controller {
	
	@RequestMapping(value = "/Home")
	public String Home_page() {
		return "index";	
}
	@RequestMapping(value = "/Register")
	public String register_page() {
		return "register";	
}
	@RequestMapping(value = "/Login")
	public String login_page() {
		return "login";	
}
	
}
