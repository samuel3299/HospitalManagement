package com.Samuel.Hospital_manager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Samuel.Hospital_manager.service.DoctorServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@AllArgsConstructor
public class DoctorController {

	@Autowired
	DoctorServiceInterface doctorServiceInterface;
	
	@RequestMapping(value = "/doctorRegistration")
	public String doctorRegistration() {
		return "doctorReg";
	}
	
	@RequestMapping(value = "/doctorPage")
	public String ProcessDoctorRegistration(@RequestParam String doc_dept,
			@RequestParam String doc_name,
			@RequestParam Double doc_salary, @RequestParam String doc_mail,
			@RequestParam String doc_password, @RequestParam String confirmPassword) {
		try {
			boolean res =  doctorServiceInterface.ProcessDoctorRegistration(doc_dept,doc_name,
					doc_salary,doc_mail,doc_password,confirmPassword);
			if(res == true) return "docPage";
			return "success";
		}
		catch(Exception e) {
			log.error("error occured: "+e);
			return "error";
		}
	}
}
