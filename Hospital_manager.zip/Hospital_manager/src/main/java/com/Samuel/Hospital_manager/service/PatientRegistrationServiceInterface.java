package com.Samuel.Hospital_manager.service;

import org.springframework.stereotype.Service;

public interface PatientRegistrationServiceInterface {

	public default boolean processRegistration(String patientName, String docIncharge, String patientSymptoms, int patientAge,
			String patientMail, String patientPassword, String confirmPassword) {return false;}

}
