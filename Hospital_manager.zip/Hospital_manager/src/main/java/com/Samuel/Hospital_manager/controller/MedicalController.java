package com.Samuel.Hospital_manager.controller;

import java.sql.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Samuel.Hospital_manager.service.MedicineServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@AllArgsConstructor
public class MedicalController {

	MedicineServiceInterface medicineServiceInterface;
	
	@RequestMapping(value = "/medicalRegForm")
	public String MedicineRegForm() {
		try {
		return "medReg";
		}
		catch(Exception e) {
			log.error(""+e);
			return "error";
		}
	}
	
	@RequestMapping(value = "/medicinePage")
	public String submitMedRegForm(@RequestParam String med_name,
			@RequestParam String company_name,
			@RequestParam Date expires_on,
			@RequestParam Date imported_on,
			@RequestParam Double med_rate,
			@RequestParam String medical_emp_mail,
			@RequestParam String medical_emp_password,
			@RequestParam String confirmPassword) {
		boolean res = medicineServiceInterface.submitMedRegForm(med_name,company_name,expires_on,
				imported_on,med_rate,medical_emp_mail,medical_emp_password,confirmPassword);
		if(res == true) return"medPage";
		return "error";
	}
}
