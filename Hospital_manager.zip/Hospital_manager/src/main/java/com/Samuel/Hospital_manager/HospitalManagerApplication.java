package com.Samuel.Hospital_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagerApplication.class, args);
	}

}
