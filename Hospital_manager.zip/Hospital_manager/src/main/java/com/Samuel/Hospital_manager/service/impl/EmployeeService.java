package com.Samuel.Hospital_manager.service.impl;

import java.sql.Date;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Employees;
import com.Samuel.Hospital_manager.repository.EmpLoginRepository;
import com.Samuel.Hospital_manager.service.EmployeeServiceInterface;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class EmployeeService implements EmployeeServiceInterface
{

	EmpLoginRepository empLoginRepository;

	@Override
	public boolean submitEmpRegForm(String department_name, String emp_name, Date emp_joining_date, Integer emp_salary,
			String emp_mail, String emp_password, String confirmPassword) {
		// TODO Auto-generated method stub
		if(!emp_password.equals(confirmPassword)) return false;
		
		Employees emp = new Employees();
		emp.setDepartment_name(department_name);
		emp.setEmp_joining_date(emp_joining_date);
		emp.setEmp_name(emp_name);
		emp.setEmp_password(emp_password);
		emp.setEmp_salary(emp_salary);
		emp.setUserMail(emp_mail);
		empLoginRepository.save(emp);
		return true;
	}
}
