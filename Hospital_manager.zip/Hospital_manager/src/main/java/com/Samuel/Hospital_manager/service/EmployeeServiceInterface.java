package com.Samuel.Hospital_manager.service;

import java.sql.Date;

public interface EmployeeServiceInterface {

	public boolean submitEmpRegForm(String department_name, String emp_name, Date emp_joining_date, Integer emp_salary,
			String emp_mail, String emp_password, String confirmPassword);

}
