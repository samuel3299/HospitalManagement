package com.Samuel.Hospital_manager.service.impl;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Department;
import com.Samuel.Hospital_manager.repository.DepartmentLoginRepository;
import com.Samuel.Hospital_manager.service.DepartmentServiceInterface;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class DepartmentService implements DepartmentServiceInterface {

	DepartmentLoginRepository departmentLoginRepository;

	@Override
	public boolean processDeptRefForm(String dept_incharge, String dept_name, Integer workers_in_dept,
			String incharge_mail, String dept_password, String confirmPassword) {
		// TODO Auto-generated method stub
		if(!dept_password.equals(confirmPassword)) return false;
		
		Department dept = new Department();
		dept.setDept_incharge(dept_incharge);
		dept.setDept_name(dept_name);
		dept.setIncharge_password(dept_password);
		dept.setUserMail(incharge_mail);
		dept.setWorkers_in_dept(workers_in_dept);
		departmentLoginRepository.save(dept);
		return true;
	}
}
