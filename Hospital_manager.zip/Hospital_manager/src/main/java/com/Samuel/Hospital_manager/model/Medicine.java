package com.Samuel.Hospital_manager.model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(name = "medicines")
@Data 
public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int med_id;
	
	@Column(unique = true)
	private String med_name;
	@Column(unique = true, name = "medicalEmp_mail")
	private String userMail;
	
	@Column(unique = true)
	private String medicalEmp_password;
	
	
	private String company_name;
	
	private double med_rate;
	
	@CreationTimestamp
	private Date imported_on;
	
	private Date Expires_on;

	
}
