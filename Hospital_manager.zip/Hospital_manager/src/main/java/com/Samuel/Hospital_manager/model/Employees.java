package com.Samuel.Hospital_manager.model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(name = "employee")
@Data
public class Employees {

	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int emp_id;
	 
	 @Column(unique= true)
	 private String emp_name;
	 
	 @Column(unique = true, name = "emp_mail")
		private String userMail;
		
		@Column(unique = true)
		private String emp_password;
		
		
	 private String department_name;
	 
	 private double emp_salary;
	 
	 @CreationTimestamp
	 private Date emp_joining_date;
	 
	 
}
