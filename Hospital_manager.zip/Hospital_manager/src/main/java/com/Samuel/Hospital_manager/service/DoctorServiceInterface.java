package com.Samuel.Hospital_manager.service;

import java.util.List;

import com.Samuel.Hospital_manager.model.Doctor;

public interface DoctorServiceInterface {

	public default boolean ProcessDoctorRegistration(String doc_dept,String doc_name,Double doc_salary,String doc_mail,
			String doc_password,String confirmPassword) {return false;}

	public default List<Doctor> findallDoctors(){return null;};
}
