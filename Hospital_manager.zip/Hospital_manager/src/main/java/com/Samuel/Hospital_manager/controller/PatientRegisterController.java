package com.Samuel.Hospital_manager.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Samuel.Hospital_manager.model.Doctor;
import com.Samuel.Hospital_manager.service.DoctorServiceInterface;
import com.Samuel.Hospital_manager.service.PatientRegistrationServiceInterface;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
@AllArgsConstructor
public class PatientRegisterController {

	PatientRegistrationServiceInterface patientRegistrationServiceInterface;
	
	DoctorServiceInterface doctorServiceInterface;

	@RequestMapping(value = "/processRegForm")
	public String processDept(@RequestParam String patientName,
			@RequestParam String docIncharge,
			@RequestParam String patientSymptoms,
			@RequestParam int patientAge,
			@RequestParam String patientMail,
			@RequestParam String patientPassword,
			@RequestParam String confirmPassword) {
		boolean res = patientRegistrationServiceInterface.processRegistration(patientName,docIncharge,
				patientSymptoms,patientAge,patientMail,patientPassword,confirmPassword);
		
		 
			if(res == true)return "patientPage";
		return "error";
	}
	@RequestMapping(value = "/getDocDetails", method = RequestMethod.GET)
	public String getMethodName(Model model) {
		List<Doctor> doctors = doctorServiceInterface.findallDoctors();
		model.addAttribute("doctors", doctors);
		return "patientPage";
	}
	
}