package com.Samuel.Hospital_manager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Samuel.Hospital_manager.service.DepartmentServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@AllArgsConstructor
public class DepartmentController {


	DepartmentServiceInterface departmentServiceInterface;
	
	@RequestMapping(value = "/departmentRegistration")
	public String departmentReg() {
		try {
		return "deptReg";
		}
		catch(Exception e) {
			log.error("error");
			return "error";
		}
	}
	
	@RequestMapping(value = "/deptPage")
	public String processDeptRefForm(@RequestParam String dept_incharge,
			@RequestParam String dept_name,
			@RequestParam Integer workers_in_dept,
			@RequestParam String incharge_mail,
			@RequestParam String incharge_password,
			@RequestParam String confirmPassword) {
		try {
			boolean res = departmentServiceInterface.processDeptRefForm(dept_incharge,dept_name
					,workers_in_dept,incharge_mail,incharge_password,confirmPassword);
			if(res == true) return "deptPage";
			return "error";
		}
		catch(Exception e) {
			log.error("Error occured: "+e);
			return "error";
		}
	}
	
}
