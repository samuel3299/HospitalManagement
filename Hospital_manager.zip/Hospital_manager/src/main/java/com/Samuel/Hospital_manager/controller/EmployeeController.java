package com.Samuel.Hospital_manager.controller;

import java.sql.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Samuel.Hospital_manager.service.EmployeeServiceInterface;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@AllArgsConstructor
@Slf4j
public class EmployeeController {

	EmployeeServiceInterface employeeServiceInterface;
	
	@RequestMapping(value = "/employeeRegistration")
	public String employeeRegPage() {
		try {
		return "empReg";
		}
		catch(Exception e) {
			log.error("error");
			return "error";
		}
	}
	
	@RequestMapping(value = "/employeePage")
	public String submitEmpRegForm(@RequestParam String department_name,
			@RequestParam String emp_name,
			@RequestParam Date emp_joining_date,
			@RequestParam Integer emp_salary,
			@RequestParam String emp_mail,
			@RequestParam String emp_password,
			@RequestParam String confirmPassword) {
		try {
			boolean res = employeeServiceInterface.submitEmpRegForm(department_name,
					emp_name,emp_joining_date,emp_salary,emp_mail,emp_password,confirmPassword);
			if(res == true) return"empPage";
			return "error";
		}
		catch(Exception e) {
			log.error("error Occured: "+e);
			return "error";
		}
	}
	
}
