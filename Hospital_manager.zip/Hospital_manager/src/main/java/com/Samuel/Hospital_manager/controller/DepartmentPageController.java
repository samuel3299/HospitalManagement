package com.Samuel.Hospital_manager.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DepartmentPageController {

	
	@RequestMapping(value = "/processDeptForm")
	public String processDept(@RequestParam String dept_incharge,
			@RequestParam String dept_name,
			@RequestParam int workers_in_dept,
			@RequestParam String incharge_mail,
			@RequestParam String incharge_password,
			@RequestParam String confirmPassword) {
		
//		boolean res = departmentPageService.processDept(dept_incharge,dept_name,workers_in_dept,incharge_mail,incharge_password,confirmPassword);
//		if(res == true) return "deptPage";
		return "error";
	}
}
