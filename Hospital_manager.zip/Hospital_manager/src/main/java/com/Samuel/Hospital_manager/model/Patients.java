package com.Samuel.Hospital_manager.model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(name = "patients")
@Data
public class Patients {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Patient_id;
	
	@Column(unique= true)
	private String patient_name;
	
	@Column(name = "patient_mail",unique = true)
	private String userMail;
	
	private int patient_age;
	
	
	private String patient_password;
	
	
	private String doc_incharge;
	
	private String patient_symptoms;
	
	@CreationTimestamp
	private Date Patient_joined;
	
	
}