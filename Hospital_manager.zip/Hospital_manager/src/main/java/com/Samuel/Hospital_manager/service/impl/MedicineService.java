package com.Samuel.Hospital_manager.service.impl;

import java.sql.Date;

import org.springframework.stereotype.Service;

import com.Samuel.Hospital_manager.model.Medicine;
import com.Samuel.Hospital_manager.repository.MedicineLoginRepository;
import com.Samuel.Hospital_manager.service.MedicineServiceInterface;

import lombok.AllArgsConstructor;
@Service
@AllArgsConstructor
public class MedicineService implements MedicineServiceInterface{
	
	MedicineLoginRepository medicineLoginRepository;
	
	@Override
	public boolean submitMedRegForm(String med_name, String company_name, Date expires_on, Date imported_on,
			Double med_rate, String medical_emp_mail, String medical_emp_password, String confirmPassword) {
		// TODO Auto-generated method stub
	
	if(!medical_emp_password.equals(confirmPassword)) return false;
	Medicine med = new Medicine();
	med.setCompany_name(company_name);
	med.setExpires_on(expires_on);
	med.setImported_on(imported_on);
	med.setMed_name(med_name);
	med.setMed_rate(med_rate);
	med.setMedicalEmp_password(medical_emp_password);
	med.setUserMail(medical_emp_mail);
	medicineLoginRepository.save(med);
	return true;
	}

}
