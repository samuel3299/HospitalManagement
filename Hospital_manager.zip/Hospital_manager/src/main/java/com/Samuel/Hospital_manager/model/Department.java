package com.Samuel.Hospital_manager.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="Department")
@Data
public class Department {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dept_id;
	
	@Column(unique = true)
	private String dept_name;
	
	@Column(unique = true, name = "incharge_mail")
	private String userMail;
	
	@Column(unique = true)
	private String incharge_password;
	
	
	private int workers_in_dept;
	private String dept_incharge;
	
	
}
