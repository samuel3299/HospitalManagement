package com.Samuel.Hospital_manager.service;

import java.sql.Date;

public interface MedicineServiceInterface {

	public boolean submitMedRegForm(String med_name, String company_name, Date expires_on, Date imported_on, Double med_rate,
			String medical_emp_mail, String medical_emp_password, String confirmPassword);

}
